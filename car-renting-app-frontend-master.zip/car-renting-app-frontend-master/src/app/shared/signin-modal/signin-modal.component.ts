import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signin-modal',
  templateUrl: './signin-modal.component.html',
  styleUrls: ['./signin-modal.component.css']
})
export class SigninModalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
