import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-vehicle',
  templateUrl: './book-vehicle.component.html',
  styleUrls: ['./book-vehicle.component.css']
})
export class BookVehicleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
